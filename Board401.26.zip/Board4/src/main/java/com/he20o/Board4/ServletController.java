package com.he20o.Board4;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.he20o.util.Cw;

@WebServlet("/board/*")
public class ServletController extends HttpServlet {
       
	String nextPage;
	Board4Dao dao;

	@Override
	public void init() throws ServletException {
		dao = new Board4Dao();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getPathInfo();
		Cw.wn("action:"+action);
		if(action!=null) {
			switch(action) {
			case "/del":		//기존 ServletDel 삭제
				Cw.wn("삭제");
				nextPage = "/list.jsp";
				dao.del(request.getParameter("no"));
				break;
			
				
			}
			RequestDispatcher d = request.getRequestDispatcher(nextPage);
			d.forward(request,response);
		}
	}


}
