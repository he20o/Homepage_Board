package com.he20o.Board4;

public class Board4Dto {

	public String no;
	public String title;
	public String id;
	public String datetime;
	public String hit;
	public String content;
	public String replyCount;
	public String replyOri;
	
	
	
public Board4Dto(String title, String content) {
	super();
	this.title = title;
	this.content = content;

}

	
	
	
	
	/* 쓰기 */
	public Board4Dto(String title, String id, String content) {
		super();
		this.title = title;
		this.id = id;
		this.content = content;
	}


	/* 읽기 ,리스트 등*/
	public Board4Dto(String no, String title, String id, String datetime, String hit, String content, String replyCount,
			String replyOri) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
		this.content = content;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}
	
	

	
}
