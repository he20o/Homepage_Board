package com.he20o.Board4;

//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.Statement;

public class Board4Db {
	
	static public final String
	DB_PACKAGE = "com.mysql.cj.jdbc.Driver";		//mysql
	// oracle일 경우 
	//static private String DB_PACKAGE = "oracle.jdbc.OracleDriver";
	
	static private String DB_NAME ="Board4";
	static private String DB_URL_MYSQL = "jdbc:mysql://localhost:3306/"+DB_NAME;		//my sql
	//oracle일 경우
	//static private String DB_URL_ORACLE = "jdbc:oracle:thin:@127.0.0.1:1521:"+DB_NAME;
	static public String DB_URL = DB_URL_MYSQL;    //DB 바뀌면 여기 바꾸기.
	static public String DB_ID = "root";
	static public String DB_PW = "0000";
	
	/*table들*/
	///게시판///
	public static final String TABLE_D_BOARD4  = "d_board4";		//자유게시판
	
	//static public String tableNameBoard = "board";
	
//	static public Connection con = null;
//	static public Statement stmt = null;
//	static public ResultSet rs = null;
//	static public int result =0;
//	
//	static public void connectBoard4Db() throws Exception{
//		Class.forName(DB_PACKAGE);
//		con = DriverManager.getConnection(DB_URL,DB_ID,DB_PW);
//		stmt = con.createStatement();
//	}
//	
//	static public void disconnectBoard4Db() throws Exception{
//		rs.close();			//db 연결 종료처리
//		stmt.close();		//db 연결 종료처리
//		con.close(); 		//db 연결 종료처리
//
//}


}
