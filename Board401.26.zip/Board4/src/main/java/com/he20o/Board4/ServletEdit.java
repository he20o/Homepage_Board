package com.he20o.Board4;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/ServletEdit")
public class ServletEdit extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Board4Dto dto = new Board4Dto(request.getParameter("title"), request.getParameter("content"));

		Board4Dao dao = new Board4Dao();
		dao.edit(dto, request.getParameter("no"));

		response.sendRedirect("list.jsp");
	}

}


// xxx.proc.jsp 를 Servlet에서 하는 것.