package com.he20o.Board4;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Board4Dao extends Dao {

	/* 쓰기 (1/5) */
	public void write(Board4Dto wr) {
		connect();

		String sql = String.format("insert into %s(b_title,b_id,b_content)values('%s','%s','%s')",
				Board4Db.TABLE_D_BOARD4, wr.title, wr.id, wr.content);
		update(sql);
		close();
	}

	/* 읽기 (2/5) */
	public Board4Dto read(String no) {
		connect();
		Board4Dto post = null;

		try {

			String sql = String.format("select * from %s where b_no= %s", Board4Db.TABLE_D_BOARD4, no);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Board4Dto(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
					rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_content"),
					rs.getString("b_reply_count"), rs.getString("b_reply_ori"));
		} catch (Exception e) {

			e.printStackTrace();
		}
		close();
		return post;
	}

	/* 리스트 (3/5) */
	public ArrayList<Board4Dto> list(String page) {
		connect();
		ArrayList<Board4Dto> posts = new ArrayList<>();

		try {
			int startIndex = ((Integer.parseInt(page)) - 1) * 3;
			String sql = String.format("select*from %s limit %s,3", Board4Db.TABLE_D_BOARD4, startIndex);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				posts.add(new Board4Dto(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
						rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_content"),
						rs.getString("b_reply_count"), rs.getString("b_reply_ori")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return posts;
	}

	/* 총 글 수 구하기 */
	public int getPostCount() {
		int count = 0;
		connect();

		try {
			String sql = String.format("select count(*) from %s", Board4Db.TABLE_D_BOARD4);
			System.out.println("sql:" + sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return count;
	}
	
	/* 총 글 수 구하기 (검색) */
	public int getSearchPostCount(String word) {
		int count = 0;
		connect();
		try {
			String sql = String.format("select count(*) from %s where b_title like '%%%s%%'", Board4Db.TABLE_D_BOARD4,word);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		}catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return count;
	}
	
	/* 리스트 (검색) */
	public ArrayList<Board4Dto> listSearch(String word,String page){
		connect();
		ArrayList<Board4Dto>posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*3;
			String sql = String.format("select * from %s where b_title like '%%%s%%' limit %s,3", Board4Db.TABLE_D_BOARD4,word,startIndex);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Board4Dto(rs.getString("b_no"),
						rs.getString("b_title"),
						rs.getString("b_id"),
						rs.getString("b_datetime"),
						rs.getString("b_hit"),
						rs.getString("b_content"),
						rs.getString("b_reply_count"),
						rs.getString("b_reply_ori")
						));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return posts;
		
	}

	/* 총 페이지 수 구하기 */
	public int getTotalPageCount() {
		int totalPageCount = 0;
		int count = getPostCount();				//만든거 다시 활용.
		
		if(count % 3 == 0) {						//case.1 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / 3;				
		}else {										//case.2 나머지가 있어서 다음 페이지가 필요한 경우
			totalPageCount = count / 3 + 1;			
		}
		return totalPageCount;
	}
	
	/* 총 페이지 수 구하기 (검색) */
	public int getSearchTotalPageCount(String word) {
		int totalPageCount = 0;
		int count = getSearchPostCount(word);
		
		if(count %3 == 0) {							//case.1 나머지가 없이 딱 떨어지는 경우
			totalPageCount = count / 3;
		}else {										//case.2 나머지가 있어서 다음 페이지가 필요한 경우
			totalPageCount = count / 3 + 1;
		}
		return totalPageCount;
	}
	
	
	/* 삭제 (4/5) */
	public void del(String no) {
		connect();
		String sql = String.format("delete from %s where b_no=%s", Board4Db.TABLE_D_BOARD4, no);
		update(sql);
		close();
	}

	/* 수정하기 (5/5) */
	public void edit(Board4Dto e, String no) {
		connect();
		String sql = String.format("update %s set b_title='%s',b_content='%s' where b_no='%s'", Board4Db.TABLE_D_BOARD4,
				e.title, e.content, no);
		update(sql);
		close();
	}
}
