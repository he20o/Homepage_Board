package he20o.com.BoardTest2;

import java.sql.ResultSet;
import java.util.ArrayList;

public class BoardDao extends BoardDb {

	/* 쓰기 */

	public void write(BoardDto wr) {
		try {
			connectBoardDb();
			String sql = String.format("insert into %s(b_title,b_id,b_text) values('%s','%s','%s')", BoardDb.TABLE_D_Test,
					wr.title, wr.id, wr.text);
			update(sql);
			disconnectBoardDb();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	void update(String sql) {
		try {
			stmt.executeUpdate(sql);
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	/* 읽기 */
	public BoardDto read(String no) {
		BoardDto post = null;

		try {
			connectBoardDb();
			String sql = String.format("select * from %s where b_no= %s", BoardDb.TABLE_D_Test, no);
			System.out.println("sql:" + sql);
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			post = new BoardDto(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
					rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
					rs.getString("b_reply_count"), rs.getString("b_reply_ori"));
			disconnectBoardDb();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return post;

	}

	/* 리스트 */

	public ArrayList<BoardDto> list(String page) {
		ArrayList<BoardDto> posts = new ArrayList<>();

		try {
			connectBoardDb();
			int startIndex = ((Integer.parseInt(page))- 1) * 3;
			String sql = String.format("select*from %s limit %s,3;", BoardDb.TABLE_D_Test, startIndex);
			System.out.println("sql:" + sql);
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				posts.add(new BoardDto(rs.getString("b_no"), rs.getString("b_title"), rs.getString("b_id"),
					rs.getString("b_datetime"), rs.getString("b_hit"), rs.getString("b_text"),
					rs.getString("b_reply_count"), rs.getString("b_reply_ori")));
			}
			disconnectBoardDb();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return posts;

	}

	/* 총 글 수 */

	public int getPostCount() {

		int count = 0;

		try {
			connectBoardDb();
			String sql = String.format("select count(*) from %s", BoardDb.TABLE_D_Test);
			System.out.println("sql:" + sql);
			ResultSet rs = stmt.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
			disconnectBoardDb();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	/* 삭제 */

	public void del(String no) {
		try {
			connectBoardDb();
			String sql = String.format("delete from %s where b_no=%s", BoardDb.TABLE_D_Test, no);
			update(sql);
			disconnectBoardDb();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}

	/* 수정하기 */

	public void edit(BoardDto e, String no) {
		try {
			connectBoardDb();
			String sql = String.format("update %s set b_title='%s',b_text='%s' where b_no='%s'", BoardDb.TABLE_D_Test,
					e.title,e.text,no);
			update(sql);
			disconnectBoardDb();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}
